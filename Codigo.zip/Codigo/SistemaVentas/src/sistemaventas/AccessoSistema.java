
package sistemaventas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author Jhoanthan
 */

public class AccessoSistema extends javax.swing.JFrame {

    public Timer objetotimer;
    public int a;

    public AccessoSistema() {
        initComponents();
        ponerFondo();
    }
    
    public void IniciarSesion() {
        final String u = "Java", p = "123";
        String user = txtUsuario.getText();
        String pass = this.txtContraseña.getText();
        objetotimer = new Timer(80, new claseTimer());
        try {
            //chekar si el usuario escrbio el nombre de usuario y pw
            if (txtUsuario.getText().length() > 0 && txtContraseña.getText().length() > 0) {
                // Si el usuario si fue validado correctamente
                if (user.equals(u) && pass.equals(p)) //enviar datos a validar
                {
                    objetotimer.start();

                } else {
                    JOptionPane.showMessageDialog(null, "El nombre de usuario y/o contrasenia no son validos.");
                    JOptionPane.showMessageDialog(null, txtUsuario.getText() + " " + txtContraseña.getText());
                    txtUsuario.setText("");    //limpiar campos
                    txtContraseña.setText("");
                    txtUsuario.requestFocusInWindow();
                }

            } else {
                JOptionPane.showMessageDialog(null, "Debe escribir nombre de usuario y contrasenia.\n"
                                                    + "NO puede dejar ningun campo vacio");
                txtUsuario.setText("");    //limpiar campos
                txtContraseña.setText("");
                txtUsuario.requestFocusInWindow();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
     private void ponerFondo(){
         
        ImageIcon imagenFondo;
        ImageIcon pintarFondo;
        
        imagenFondo = new ImageIcon(getClass().getResource("/Imagenes/faro.jpg"));        
        pintarFondo = new ImageIcon(imagenFondo.getImage().getScaledInstance(Fondo.getWidth(), Fondo.getHeight(), Image.SCALE_DEFAULT));
        Fondo.setIcon(pintarFondo);
    
     }
    
    private void cerrar(){
    this.dispose(); 
}

    public class claseTimer implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            a = barraProgr.getValue();
            if (a < 100) {
                a++;
                barraProgr.setValue(a);
            } else { //Como ya llegó a 100, no entra en el anterior if, sino en este:
                objetotimer.stop();
                SistemaV fr2 = new SistemaV();
                fr2.setEnabled(true);
                fr2.show();
                cerrar();
            }

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        lblContrasenia = new javax.swing.JLabel();
        txtUsuario = new java.awt.TextField();
        txtContraseña = new java.awt.TextField();
        btnAceptar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        pnlUsuario = new javax.swing.JPanel();
        lblFoto = new javax.swing.JLabel();
        barraProgr = new javax.swing.JProgressBar();
        Fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Accesso al sistema");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Lucida Fax", 2, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("BIENVENIDO A NUESTRO SISTEMA DE FACTURACION!!");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, -1, -1));

        lblUsuario.setText("Usuario:");
        getContentPane().add(lblUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, -1, -1));

        lblContrasenia.setText("Contraseña:");
        getContentPane().add(lblContrasenia, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));
        getContentPane().add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 170, -1));

        txtContraseña.setEchoChar('*');
        getContentPane().add(txtContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 170, -1));

        btnAceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fg[1].jpg"))); // NOI18N
        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAceptar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, -1, -1));

        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/16 (Delete).jpg"))); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, -1, 29));

        pnlUsuario.setBackground(new java.awt.Color(255, 255, 255));
        pnlUsuario.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/logg.png"))); // NOI18N

        javax.swing.GroupLayout pnlUsuarioLayout = new javax.swing.GroupLayout(pnlUsuario);
        pnlUsuario.setLayout(pnlUsuarioLayout);
        pnlUsuarioLayout.setHorizontalGroup(
            pnlUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuarioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblFoto)
                .addContainerGap())
        );
        pnlUsuarioLayout.setVerticalGroup(
            pnlUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsuarioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblFoto)
                .addContainerGap())
        );

        getContentPane().add(pnlUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, -1, -1));

        barraProgr.setForeground(new java.awt.Color(51, 51, 255));
        barraProgr.setStringPainted(true);
        getContentPane().add(barraProgr, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 382, 26));
        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
        // TODO add your handling code here:
        IniciarSesion(); 
    
    }//GEN-LAST:event_btnAceptarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btnCancelarActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccessoSistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccessoSistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccessoSistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccessoSistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new AccessoSistema().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Fondo;
    private javax.swing.JProgressBar barraProgr;
    private javax.swing.JButton btnAceptar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblContrasenia;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPanel pnlUsuario;
    private java.awt.TextField txtContraseña;
    private java.awt.TextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
