
package sistemaventas;

import java.awt.HeadlessException;
import java.sql.*;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import Conexion.ClassConection;

public final class Factura extends javax.swing.JInternalFrame {
    Connection cn = null;
    CallableStatement cts = null;
    ResultSet r = null;
    String sql = null;
    ClassConection conectar = new ClassConection();
   
    int contador = 1;
   
    public Factura() throws SQLException {
        initComponents();
        cn = conectar.conecion();
        Calendar cal = Calendar.getInstance();
        String fecha = cal.get(Calendar.DATE) + "/" + cal.get(Calendar.MONTH) + "/" + cal.get(cal.YEAR);
        this.lblFecha.setText(fecha);

        try {

            cts = cn.prepareCall("{call Genera_num_Factura}");
            r = cts.executeQuery();
            if (r.next()) {
                txtRucFact.setText(r.getString(1));
            }
        } catch (Exception e) {
            
        }
    }

public static void ajustarcolumnas(){
     TableColumn columna =null;
     for(int i=0;i<=4;i++){
         columna=tblDetalle.getColumnModel().getColumn(i);
         if(i==0){
             columna.setPreferredWidth(6);
            
         }
         else if(i==1){
              columna.setPreferredWidth(250);
         }
          else if(i==2){
              columna.setPreferredWidth(20);
         }
         else {
            columna.setPreferredWidth(40); 
         }
     }
 }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtRucFact = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jtf_total = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jtf_subto = new javax.swing.JTextField();
        jtf_desc = new javax.swing.JTextField();
        jtf_igv = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDetalle = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnBuscar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lblCliente = new javax.swing.JLabel();
        lblRuc = new javax.swing.JLabel();
        lblCI = new javax.swing.JLabel();
        JLB_codCliente = new javax.swing.JLabel();
        lblDireccion = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        btnBuscarProduct = new javax.swing.JButton();
        btnCompra = new javax.swing.JButton();
        btnEliminarRgistro = new javax.swing.JButton();
        btnSalid = new javax.swing.JButton();
        btnCalcular = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        setClosable(true);
        setIconifiable(true);
        setFont(new java.awt.Font("Agency FB", 1, 10)); // NOI18N
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setText("Av. de la Prensa y 10 de Agosto Quito-Ecuador");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 52, -1, -1));

        jLabel2.setFont(new java.awt.Font("Castellar", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 51));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Restaurante ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 11, 222, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("Direccion:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 176, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Fecha:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(442, 145, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Cod.Cliente:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 145, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("R.U.C.:20248454753");

        jLabel12.setText("FACTURA DE VENTA");

        jLabel13.setText("N°:");

        txtRucFact.setEnabled(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jLabel11))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(txtRucFact, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12)
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtRucFact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 40, 250, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel14.setText("Total a Pagra:");

        jtf_total.setEditable(false);

        jLabel24.setText("Descuento 10% :");

        jLabel25.setText("Subtotal:");

        jLabel26.setText("IVA:");

        jtf_subto.setEditable(false);

        jtf_desc.setEditable(false);

        jtf_igv.setEditable(false);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtf_subto, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(jLabel24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtf_desc, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtf_igv, javax.swing.GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(jtf_total, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jtf_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24)
                    .addComponent(jLabel25)
                    .addComponent(jLabel26)
                    .addComponent(jtf_subto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtf_desc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtf_igv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblDetalle.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(204, 204, 255)));
        tblDetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CODIGO", "DESCRIPCION", "CANTIDAD", "PRECIO UNITARIO", "PRECIO VENTA"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblDetalle);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 206, 710, -1));

        jLabel5.setText("Telefonos: 044-456555  //  981360733");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(358, 72, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Señor(es):");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/16 (Search).jpg"))); // NOI18N
        btnBuscar.setText("...");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 104, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("DNI:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 145, -1, -1));

        jLabel3.setText("SAKURA SUSHI BAR - COMIDA JAPONESA ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(348, 32, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("R.U.C:");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(442, 110, -1, -1));

        lblCliente.setForeground(new java.awt.Color(0, 153, 153));
        lblCliente.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lblCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 110, 267, 19));

        lblRuc.setForeground(new java.awt.Color(0, 153, 153));
        lblRuc.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lblRuc, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, 105, 19));

        lblCI.setForeground(new java.awt.Color(0, 153, 153));
        lblCI.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lblCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 140, 150, 19));

        JLB_codCliente.setForeground(new java.awt.Color(0, 153, 153));
        JLB_codCliente.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(JLB_codCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(307, 140, 104, 19));

        lblDireccion.setForeground(new java.awt.Color(0, 153, 153));
        lblDireccion.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lblDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 176, 252, 19));

        lblFecha.setForeground(new java.awt.Color(0, 153, 153));
        lblFecha.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lblFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(484, 140, 79, 19));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel23.setText("Articulo:");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(337, 175, -1, -1));

        btnBuscarProduct.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/16 (Search).jpg"))); // NOI18N
        btnBuscarProduct.setText("PRODUCTOS");
        btnBuscarProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarProductActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscarProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(394, 170, 128, -1));

        btnCompra.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/16 (Save).jpg"))); // NOI18N
        btnCompra.setText("REALIZAR VENTA");
        btnCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompraActionPerformed(evt);
            }
        });
        getContentPane().add(btnCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 320, 157, 44));

        btnEliminarRgistro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/16 (User delete).jpg"))); // NOI18N
        btnEliminarRgistro.setText("ELIMINAR ARTICULO");
        btnEliminarRgistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarRgistroActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminarRgistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 270, 157, 44));

        btnSalid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/16 (Delete).jpg"))); // NOI18N
        btnSalid.setText("SALIR");
        btnSalid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalidActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalid, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 370, 157, 44));

        btnCalcular.setText("CALCULAR OPERACION");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });
        getContentPane().add(btnCalcular, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 220, 157, 44));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/gg.jpg"))); // NOI18N
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, -10, 70, 110));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void btnBuscarProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarProductActionPerformed
        // TODO add your handling code here:
        BuscarProductos bs;
        try {
            bs = new BuscarProductos();
            SistemaV.jDesktopPane1.add(bs);
            bs.toFront();
            bs.setLocation(50, 10);
            bs.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Factura.class.getName()).log(Level.SEVERE, null, ex);
        }

      
    }//GEN-LAST:event_btnBuscarProductActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        // TODO add your handling code here:
        BuscarCliente bc=new BuscarCliente();
        SistemaV.jDesktopPane1.add(bc);
        bc.toFront();
        bc.setLocation(50,10);
        bc.setVisible(true);
        
    }//GEN-LAST:event_btnBuscarActionPerformed

    
    private void agregarfactura() {
        
        txtRucFact.setText("F"+contador);
        String nfac = txtRucFact.getText();
        String fec = lblFecha.getText();
        String codcli = JLB_codCliente.getText();
        String ruc = lblRuc.getText();
        String subt = jtf_subto.getText().toString();
        String desc = jtf_desc.getText().toString();
        String ivg = jtf_igv.getText().toString();
        String tot = jtf_total.getText().toString();

        try {
            cts = cn.prepareCall("{call InsertaFacturas(?,?,?,?,?,?,?,?)}");
            cts.setString(1, nfac);
            cts.setString(2, fec);
            cts.setString(3, codcli);
            cts.setString(4, ruc);
            cts.setString(5, subt);
            cts.setString(6, desc);
            cts.setString(7, ivg);
            cts.setString(8, tot);
            int opcion = cts.executeUpdate();
            if (opcion == 1) {
                JOptionPane.showMessageDialog(this, "factura registrado coreectamente", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException | HeadlessException e) {
            
            JOptionPane.showMessageDialog(this, "Error al registrar");
        }

    }
    
    private void agregarDETALLEfactura() {
        
        for (int i = 0; i < tblDetalle.getRowCount(); i++) {
            String nfac = txtRucFact.getText();
            String codpro = tblDetalle.getValueAt(i, 0).toString();
            String prod = tblDetalle.getValueAt(i, 1).toString();
            String cant = tblDetalle.getValueAt(i, 2).toString();
            String pre_u = tblDetalle.getValueAt(i, 3).toString();
            String pre_v = tblDetalle.getValueAt(i, 4).toString();

            try {
                cts = cn.prepareCall("{call insertarDetFactura(?,?,?,?,?,?)}");
                cts.setString(1, nfac);
                cts.setString(2, codpro);
                cts.setString(3, prod);
                cts.setString(4, cant);
                cts.setString(5, pre_u);
                cts.setString(6, pre_v);

                int opcion = cts.executeUpdate();
                if (opcion == 1) {
                    JOptionPane.showMessageDialog(this, "Registrado correctamente!!", "aviso", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al registrar" + e.getMessage());

            }
        }
    }
    
    
    private void btnCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompraActionPerformed
        // TODO add your handling code here:
        agregarfactura();
        agregarDETALLEfactura();
        contador++;
       
    }//GEN-LAST:event_btnCompraActionPerformed

    private void btnEliminarRgistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarRgistroActionPerformed
        // TODO add your handling code here:
         DefaultTableModel modelo = (DefaultTableModel) tblDetalle.getModel();
        //ahora obtenemos la fila selccionada
        int fila_select = tblDetalle.getSelectedRow();

        if(fila_select<0){
            // no se puede eliminar
            JOptionPane.showMessageDialog(this,"Tabla vacia o no ha seleccionado uan fila.");
        }else {
          // la eliminamos del modelo:
        modelo.removeRow(fila_select);
        }

        
    }//GEN-LAST:event_btnEliminarRgistroActionPerformed

    private void btnSalidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalidActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(null, "Realmente decea Salir", "confirmar", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_NO_OPTION) {
            this.dispose();

        }


    }//GEN-LAST:event_btnSalidActionPerformed

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        // TODO add your handling code here:
        
         double suma=0.0;
         double subtot=0.0;
         double des=0.0;
         double iv =0.0;
         double total=0.0;
            for (int i = 0; i < tblDetalle.getRowCount(); i++) {
                
            String precio = tblDetalle.getValueAt(i, 3).toString();
            String cantidad = tblDetalle.getValueAt(i, 2).toString();
            int c = Integer.parseInt(cantidad);
            double p = Double.parseDouble(precio);
            suma = c * p;
            subtot += suma;
            des = (subtot * (10 / 100));
            iv = (subtot * (12 / 100));
            total = subtot - des;
            
            tblDetalle.setValueAt(suma, i, 4);
            jtf_subto.setText("" + subtot);
            jtf_desc.setText("" + des);
            jtf_igv.setText("" + iv);
            jtf_total.setText("" + total);

        }

         
    }//GEN-LAST:event_btnCalcularActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JLabel JLB_codCliente;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnBuscarProduct;
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnCompra;
    private javax.swing.JButton btnEliminarRgistro;
    private javax.swing.JButton btnSalid;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jtf_desc;
    private javax.swing.JTextField jtf_igv;
    public static javax.swing.JTextField jtf_subto;
    private javax.swing.JTextField jtf_total;
    public static javax.swing.JLabel lblCI;
    public static javax.swing.JLabel lblCliente;
    public static javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblFecha;
    public static javax.swing.JLabel lblRuc;
    public static javax.swing.JTable tblDetalle;
    private javax.swing.JTextField txtRucFact;
    // End of variables declaration//GEN-END:variables
}
